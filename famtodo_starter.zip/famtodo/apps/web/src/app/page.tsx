
export default function Page() {
  return (
    <main style={{padding: 24}}>
      <h1>FamTodo</h1>
      <p>Next.js + BetterAuth + self-hosted Supabase (PostgREST/Realtime)</p>
      <ul>
        <li>Docker + Dokploy ready</li>
        <li>RLS + Realtime</li>
        <li>Shopping liste m. auto-kategorisering</li>
      </ul>
    </main>
  );
}
